package upo.graph.impl;

public class DatiStudente {
    public final static String matricola = "20045207";
}
